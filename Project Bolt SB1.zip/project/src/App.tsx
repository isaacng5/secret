import React, { useState } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { FileList } from './components/FileList';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { useThemeStore } from './store/theme';
import { useChatStore } from './store/chat';

interface FileItem {
  id: string;
  name: string;
  size: number;
  status: 'uploading' | 'complete' | 'error';
  progress?: number;
}

function App() {
  const { isDarkMode } = useThemeStore();
  const { messages, addMessage } = useChatStore();
  const [files, setFiles] = useState<FileItem[]>([]);

  const handleFileUpload = (file: File) => {
    const newFile: FileItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      status: 'uploading',
      progress: 0,
    };

    setFiles((prev) => [...prev, newFile]);

    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      if (progress <= 100) {
        setFiles((prev) =>
          prev.map((f) =>
            f.id === newFile.id ? { ...f, progress } : f
          )
        );
      } else {
        clearInterval(interval);
        setFiles((prev) =>
          prev.map((f) =>
            f.id === newFile.id ? { ...f, status: 'complete' } : f
          )
        );
      }
    }, 500);
  };

  const handleDeleteFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleSendMessage = (text: string) => {
    addMessage({ text, isUser: true });

    // Simulate bot response - replace with actual OpenAI call
    setTimeout(() => {
      addMessage({
        text: "I'm analyzing your PDF and will respond shortly...",
        isUser: false,
      });
    }, 1000);
  };

  return (
    <div className={isDarkMode ? 'dark' : ''}>
      <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <Header onSettingsClick={() => {}} />

        <div className="pt-16 h-screen flex">
          {/* Left Panel */}
          <div className="w-1/3 border-r border-gray-200 dark:border-gray-800 p-4 space-y-4">
            <FileUpload onFileUpload={handleFileUpload} />
            <FileList files={files} onDelete={handleDeleteFile} />
          </div>

          {/* Right Panel */}
          <div className="flex-1 flex flex-col p-4">
            <div className="flex-1 space-y-4 overflow-y-auto">
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={message.text}
                  isUser={message.isUser}
                  timestamp={message.timestamp}
                />
              ))}
            </div>
            <div className="pt-4">
              <ChatInput onSendMessage={handleSendMessage} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;