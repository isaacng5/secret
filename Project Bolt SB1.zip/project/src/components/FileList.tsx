import React from 'react';
import { Trash2, CheckCircle, AlertCircle } from 'lucide-react';

interface FileItem {
  id: string;
  name: string;
  size: number;
  status: 'uploading' | 'complete' | 'error';
  progress?: number;
}

interface FileListProps {
  files: FileItem[];
  onDelete: (id: string) => void;
}

export function FileList({ files, onDelete }: FileListProps) {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-4">
      {files.map((file) => (
        <div
          key={file.id}
          className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm flex items-center gap-4"
        >
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              {file.status === 'complete' && <CheckCircle className="w-5 h-5 text-green-500" />}
              {file.status === 'error' && <AlertCircle className="w-5 h-5 text-red-500" />}
              <p className="font-medium truncate">{file.name}</p>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {formatFileSize(file.size)}
            </p>
            {file.status === 'uploading' && (
              <div className="mt-2 h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 transition-all duration-300"
                  style={{ width: `${file.progress}%` }}
                />
              </div>
            )}
          </div>
          <button
            onClick={() => onDelete(file.id)}
            className="p-2 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      ))}
    </div>
  );
}