import React from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, Upload } from 'lucide-react';
import { clsx } from 'clsx';

interface FileUploadProps {
  onFileUpload: (file: File) => void;
}

export function FileUpload({ onFileUpload }: FileUploadProps) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'application/pdf': ['.pdf']
    },
    onDrop: files => {
      if (files[0]) onFileUpload(files[0]);
    }
  });

  return (
    <div
      {...getRootProps()}
      className={clsx(
        'border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors',
        'hover:border-[#6eb3c0] hover:bg-[#6eb3c0]/10 dark:hover:bg-blue-900/20',
        isDragActive ? 'border-[#6eb3c0] bg-[#6eb3c0]/10 dark:bg-blue-900/20' : 'border-gray-300 dark:border-gray-700'
      )}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center gap-4">
        {isDragActive ? (
          <Upload className="w-12 h-12 text-[#6eb3c0]" />
        ) : (
          <FileText className="w-12 h-12 text-gray-400" />
        )}
        <div className="space-y-2">
          <p className="text-sm font-medium">
            {isDragActive ? 'Drop your PDF here' : 'Drag your PDF here or click to upload'}
          </p>
        </div>
      </div>
    </div>
  );
}